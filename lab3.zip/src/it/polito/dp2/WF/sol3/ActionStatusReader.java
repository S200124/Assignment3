package it.polito.dp2.WF.sol3;

import it.polito.dp2.WF.Actor;

import java.util.Calendar;

public class ActionStatusReader implements it.polito.dp2.WF.ActionStatusReader {
	
	@Override
	public String getActionName() {
		return null;
	}

	@Override
	public Actor getActor() {
		return null;
	}

	@Override
	public Calendar getTerminationTime() {
		return null;
	}

	@Override
	public boolean isTakenInCharge() {
		return false;
	}

	@Override
	public boolean isTerminated() {
		return false;
	}

}
